import * as types from "../actionsTypes/authActionTypes";
import fire from "../../config/firebase";

const loginUser = (payload) => ({
  type: types.SIGN_IN,
  payload,
});

const logoutUser = () => ({
  type: types.SIGN_OUT,
});

const handleError = (error) => ({
  type: types.HANDLE_ERROR,
  payload: error,
});

export const signInUser = (email, password, setSuccess) => (dispatch) => {
  fire
    .auth()
    .signInWithEmailAndPassword(email, password)
    .then((user) => {
      dispatch(
        loginUser({
          uid: user.user.uid,
          email: user.user.email,
          displayName: user.user.displayName,
        })
      );
      setSuccess(true);
    })
    .catch((error) => {
      dispatch(handleError(error.message));
      setSuccess(false);
    });
};

export const signUpUser = (name, email, password, setSuccess) => (dispatch) => {
  fire
    .auth()
    .createUserWithEmailAndPassword(email, password)
    .then(() => {
      return fire.auth().currentUser.updateProfile({
        displayName: name,
      });
    })
    .then(() => {
      const currentUser = fire.auth().currentUser;
      dispatch(
        loginUser({
          uid: currentUser.uid,
          name: currentUser.displayName,
          email: currentUser.email,
        })
      );
      setSuccess(true);
    })
    .catch((error) => {
      dispatch(handleError(error.message));
      setSuccess(false);
    });
};

export const signOutUser = () => (dispatch) => {
  fire.auth().signOut().then(() => {
    dispatch(logoutUser());
  }).catch((error) => {
    dispatch(handleError(error.message));
  });
};

export const checkedIsLoggedIn = () => (dispatch) => {
  return new Promise((resolve) => {
    fire.auth().onAuthStateChanged((user) => {
      if (user) {
        dispatch(
          loginUser({
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
          })
        );
      } else {
        dispatch(logoutUser());
      }
      resolve();
    });
  });
};
