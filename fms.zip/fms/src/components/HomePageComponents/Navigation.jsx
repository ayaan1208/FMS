// NavigationComponent.jsx

import React from 'react';
import { Link } from 'react-router-dom';

const NavigationComponent = () => {
    const navbarStyle = {
        position: 'fixed',
        width: '100%',
        top: 0,
        left: 0, // Added left: 0 to ensure it starts from the top left corner
        zIndex: 1000,
        backgroundColor: '#343a40', // Background color for the navbar
        padding: '10px', // Adjust padding as needed
    };

    return (
        <div style={navbarStyle} className="navbar-wrapper">
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <Link className="navbar-brand ms-5" to="/">
                    ClienterAI File Manager
                </Link>
                <ul className="navbar-nav ms-auto me-5">
                    <li className="nav-item mx-2">
                        <Link className="btn btn-primary btn-sm" to='/login'>
                            login
                        </Link>
                    </li>
                    <li className='nav-item'>
                        <Link className='btn btn-success btn-sm' to='/register'>
                            Register
                        </Link>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

export default NavigationComponent;
