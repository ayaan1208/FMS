import firebase from "firebase/compat/app"
import "firebase/compat/auth"

const firebaseConfig = {
    apiKey: "AIzaSyBoTvvRuQrnPM2dF1nILzyZX-cng46yLf8",
    authDomain: "aiclienter-fms-6dae2.firebaseapp.com",
    projectId: "aiclienter-fms-6dae2",
    storageBucket: "aiclienter-fms-6dae2.appspot.com",
    messagingSenderId: "559132737333",
    appId: "1:559132737333:web:eaf1e58a051c3612b0567c"
  };

  const fire = firebase.initializeApp(firebaseConfig);

  export default fire