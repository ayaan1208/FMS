import React from 'react'

const DashboardPage = () => {
  return (
    <h1>Welcome to the ClienterAI board</h1>
  )
}

export default DashboardPage