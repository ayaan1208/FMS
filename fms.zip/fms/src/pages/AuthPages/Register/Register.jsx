import React from 'react';
import RegisterForm from '../../../components/AuthComponents/RegisterForm';
import { Link } from 'react-router-dom';

const Register = () => {
    return(
        <div className="container-fluid">
            <h1 className='display-1 my-5 text-center'>Signup</h1>
            <div className="row">
               
                    <RegisterForm />
                    <Link to="/login" className='ms-auto'>
                        Already a member? Login
                    </Link>
             
            </div>
        </div>
    )
};

export default Register;
