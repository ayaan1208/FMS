import React from 'react'
import NavigationComponent from "../../components/HomePageComponents/Navigation"

export const HomePage = () => {
  return (
    <>
    <NavigationComponent />
    <h1 className='display-1 my-5 text-center'>
        ClienterAI
    </h1>
    <h2>FileManager</h2>
    </>
  )
}
