// App.jsx
import React from 'react'; 
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import './App.css';
import { HomePage } from './pages/HomePage/HomePage';
import Register from './pages/AuthPages/Register/Register';
import Login from './pages/AuthPages/Login/Login';
import DashboardPage from './pages/DashboardPage/DashboardPage';
import { checkedIsLoggedIn } from './redux/actionCreators/authActionCreator';

const App = () => {
  const dispatch = useDispatch();

  React.useEffect(() => {
    dispatch(checkedIsLoggedIn());
  }, []);

  return (
    <div className="App">
      <Router> {/* Use BrowserRouter or HashRouter here */}
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<DashboardPage />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
